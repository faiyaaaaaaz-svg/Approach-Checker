"use server";

export async function saveImportRun() {
  return { ok: true, demoMode: true, message: "Demo mode: import run save simulated." };
}

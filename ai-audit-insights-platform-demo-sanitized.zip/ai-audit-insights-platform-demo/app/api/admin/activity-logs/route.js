import { DEMO_ACTIVITY_LOGS, DEMO_SESSIONS } from "../../../../lib/demoData";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function json(data, init = {}) { return Response.json(data, { status: init.status || 200 }); }
export async function GET() { return json({ ok: true, demoMode: true, logs: DEMO_ACTIVITY_LOGS, sessions: DEMO_SESSIONS }); }
export async function POST() { return json({ ok: true, demoMode: true, message: "Demo activity log simulated." }); }

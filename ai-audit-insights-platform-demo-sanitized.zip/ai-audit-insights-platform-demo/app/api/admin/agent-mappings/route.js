import { DEMO_AGENT_MAPPINGS } from "../../../../lib/demoData";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function json(data, init = {}) { return Response.json(data, { status: init.status || 200 }); }
export async function GET() { return json({ ok: true, demoMode: true, mappings: DEMO_AGENT_MAPPINGS, rows: DEMO_AGENT_MAPPINGS }); }
export async function POST() { return json({ ok: true, demoMode: true, mappings: DEMO_AGENT_MAPPINGS, message: "Demo mode: mapping action simulated." }); }
export async function PUT() { return json({ ok: true, demoMode: true, mappings: DEMO_AGENT_MAPPINGS, message: "Demo mode: mapping update simulated." }); }
export async function DELETE() { return json({ ok: true, demoMode: true, mappings: DEMO_AGENT_MAPPINGS, message: "Demo mode: mapping delete simulated." }); }

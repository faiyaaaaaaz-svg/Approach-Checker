import { DEMO_API_KEYS } from "../../../../lib/demoData";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function json(data, init = {}) { return Response.json(data, { status: init.status || 200 }); }
export async function GET() { return json({ ok: true, demoMode: true, keys: DEMO_API_KEYS }); }
export async function POST() { return json({ ok: true, demoMode: true, keys: DEMO_API_KEYS, message: "Demo mode: API key action simulated. No key is stored." }); }
export async function DELETE() { return json({ ok: true, demoMode: true, keys: DEMO_API_KEYS, message: "Demo mode: API key delete simulated." }); }

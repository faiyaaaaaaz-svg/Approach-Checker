import { DEMO_PROMPT, DEMO_PROMPT_HISTORY } from "../../../../lib/demoData";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function json(data, init = {}) { return Response.json(data, { status: init.status || 200 }); }
export async function GET() { return json({ ok: true, demoMode: true, dbReady: true, prompt: DEMO_PROMPT, history: DEMO_PROMPT_HISTORY }); }
export async function POST(request) { const body = await request.json().catch(() => ({})); return json({ ok: true, demoMode: true, dbReady: true, prompt: { ...DEMO_PROMPT, livePrompt: body.livePrompt || body.live_prompt || DEMO_PROMPT.livePrompt, updated_at: new Date().toISOString() }, history: DEMO_PROMPT_HISTORY, message: "Demo mode: prompt save simulated." }); }

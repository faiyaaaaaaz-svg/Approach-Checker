import { DEMO_PROFILE } from "../../../../lib/demoData";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function json(data, init = {}) { return Response.json(data, { status: init.status || 200 }); }
const profiles = [DEMO_PROFILE, { id: "demo-supervisor", email: "maya.chen@example.com", full_name: "Maya Chen", role: "supervisor_admin", can_run_tests: false, is_active: true }, { id: "demo-runner", email: "audit.runner@example.com", full_name: "Audit Runner", role: "audit_runner", can_run_tests: true, is_active: true }];
export async function GET() { return json({ ok: true, demoMode: true, profiles, grants: profiles }); }
export async function POST() { return json({ ok: true, demoMode: true, profiles, grants: profiles, message: "Demo mode: role update simulated." }); }
export async function PUT() { return json({ ok: true, demoMode: true, profiles, grants: profiles, message: "Demo mode: role update simulated." }); }
export async function DELETE() { return json({ ok: true, demoMode: true, profiles, grants: profiles, message: "Demo mode: role revoke simulated." }); }

import { DEMO_PERMISSION_CATALOG, DEMO_ROLE_PERMISSIONS } from "../../../../lib/demoData";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function json(data, init = {}) { return Response.json(data, { status: init.status || 200 }); }
export async function GET() { return json({ ok: true, demoMode: true, editable: true, catalog: DEMO_PERMISSION_CATALOG, roles: DEMO_ROLE_PERMISSIONS }); }
export async function PUT(request) { const body = await request.json().catch(() => ({})); return json({ ok: true, demoMode: true, editable: true, catalog: DEMO_PERMISSION_CATALOG, roles: Array.isArray(body.roles) ? body.roles : DEMO_ROLE_PERMISSIONS, message: "Demo mode: permissions save simulated." }); }

import { DEMO_SUPERVISOR_TEAMS, DEMO_AGENT_MAPPINGS } from "../../../../lib/demoData";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function json(data, init = {}) { return Response.json(data, { status: init.status || 200 }); }
const employeeOptions = DEMO_AGENT_MAPPINGS.map((item) => ({ label: item.employee_name, value: item.employee_email, employee_name: item.employee_name, employee_email: item.employee_email, team_name: item.team_name, intercom_agent_name: item.intercom_agent_name }));
export async function GET() { return json({ ok: true, demoMode: true, teams: DEMO_SUPERVISOR_TEAMS, employeeOptions }); }
export async function POST() { return json({ ok: true, demoMode: true, teams: DEMO_SUPERVISOR_TEAMS, employeeOptions, message: "Demo mode: supervisor team action simulated." }); }
export async function PUT() { return json({ ok: true, demoMode: true, teams: DEMO_SUPERVISOR_TEAMS, employeeOptions, message: "Demo mode: supervisor team update simulated." }); }
export async function DELETE() { return json({ ok: true, demoMode: true, teams: DEMO_SUPERVISOR_TEAMS, employeeOptions, message: "Demo mode: supervisor team delete simulated." }); }

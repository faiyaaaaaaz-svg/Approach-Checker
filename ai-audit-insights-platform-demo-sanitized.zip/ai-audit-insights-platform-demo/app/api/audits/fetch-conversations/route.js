import { DEMO_CONVERSATIONS } from "../../../../lib/demoData";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function json(data, init = {}) { return Response.json(data, { status: init.status || 200 }); }
export async function POST(request) {
  const body = await request.json().catch(() => ({}));
  const ids = Array.isArray(body.conversationIds) ? body.conversationIds.map(String) : [];
  const conversations = ids.length
    ? ids.map((id, index) => DEMO_CONVERSATIONS.find((item) => String(item.id) === id) || { ...DEMO_CONVERSATIONS[index % DEMO_CONVERSATIONS.length], id, conversationId: id })
    : DEMO_CONVERSATIONS;
  return json({ ok: true, demoMode: true, conversations, done: true, fetchState: null, meta: { fetchedCount: conversations.length, processedPagesTotal: 1, source: "mock" } });
}

import { buildAuditResultFromConversation, DEMO_CONVERSATIONS } from "../../../../lib/demoData";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function json(data, init = {}) { return Response.json(data, { status: init.status || 200 }); }
export async function POST(request) {
  const body = await request.json().catch(() => ({}));
  const conversations = Array.isArray(body.conversations) && body.conversations.length ? body.conversations : DEMO_CONVERSATIONS.slice(0, 2);
  if (body.checkOnly) {
    return json({ ok: true, demoMode: true, requiresDuplicateDecision: false, duplicateSummary: null, duplicates: [], meta: { checkedCount: conversations.length } });
  }
  const results = conversations.map((item, index) => buildAuditResultFromConversation(item, index));
  return json({
    ok: true,
    demoMode: true,
    message: "Demo audit completed with mock AI output.",
    meta: {
      requestedBy: "demo.owner@example.com",
      receivedCount: conversations.length,
      handledCount: conversations.length,
      auditedCount: results.length,
      successCount: results.length,
      errorCount: 0,
      duplicateModeApplied: body.duplicateMode || "none",
      skippedCount: 0,
      overwrittenCount: 0,
      mappedCount: results.length,
      unmappedCount: 0,
      auditMode: "portfolio_demo_mock_ai",
      storageStatus: "demo_memory_only",
      storedRunIds: ["run-demo-portfolio"],
      batchSize: conversations.length,
      totalBatches: 1,
    },
    results,
  });
}

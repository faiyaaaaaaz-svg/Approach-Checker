export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function json(data, init = {}) { return Response.json(data, { status: init.status || 200 }); }
const run = { id: "workflow-demo", status: "completed", progress_percent: 100, status_message: "Demo workflow ready.", created_at: new Date().toISOString(), updated_at: new Date().toISOString() };
export async function GET() { return json({ ok: true, demoMode: true, run, queue: [], events: [] }); }
export async function POST(request) {
  const body = await request.json().catch(() => ({}));
  return json({ ok: true, demoMode: true, run: { ...run, id: body.run_id || body.runId || "workflow-demo" }, queue: [], events: [] });
}

import { DEMO_PROFILE } from "../../../../lib/demoData";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function json(data, init = {}) { return Response.json(data, { status: init.status || 200 }); }
export async function GET() { return json({ ok: true, profile: DEMO_PROFILE, demoMode: true }); }
export async function POST() { return json({ ok: true, profile: DEMO_PROFILE, demoMode: true }); }

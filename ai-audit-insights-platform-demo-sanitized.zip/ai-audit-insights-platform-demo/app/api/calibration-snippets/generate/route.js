import { DEMO_SNIPPETS } from "../../../../lib/demoData";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function json(data, init = {}) { return Response.json(data, { status: init.status || 200 }); }
export async function POST() { return json({ ok: true, demoMode: true, snippet: { ...DEMO_SNIPPETS[0], id: `generated-demo-${Date.now()}`, title: "AI-generated demo calibration snippet", is_active: false, generation_status: "draft" }, message: "Demo mode: AI snippet draft generated from mock dispute." }); }

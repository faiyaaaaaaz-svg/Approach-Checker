import { DEMO_SNIPPETS, DEMO_DISPUTES } from "../../../lib/demoData";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function json(data, init = {}) { return Response.json(data, { status: init.status || 200 }); }
export async function GET() { return json({ ok: true, demoMode: true, snippets: DEMO_SNIPPETS, disputes: DEMO_DISPUTES }); }
export async function POST(request) { const body = await request.json().catch(() => ({})); const snippet = { ...DEMO_SNIPPETS[0], id: `demo-snippet-${Date.now()}`, ...body, updated_at: new Date().toISOString() }; return json({ ok: true, demoMode: true, snippet, snippets: [snippet, ...DEMO_SNIPPETS], message: "Demo mode: snippet saved." }); }
export async function PUT(request) { const body = await request.json().catch(() => ({})); const snippet = { ...DEMO_SNIPPETS[0], ...body, updated_at: new Date().toISOString() }; return json({ ok: true, demoMode: true, snippet, snippets: [snippet], message: "Demo mode: snippet updated." }); }
export async function DELETE() { return json({ ok: true, demoMode: true, snippets: DEMO_SNIPPETS, message: "Demo mode: snippet delete simulated." }); }

import { DEMO_RESULTS, DEMO_RUNS, DEMO_SUPERVISOR_TEAMS } from "../../../lib/demoData";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function json(data, init = {}) { return Response.json(data, { status: init.status || 200 }); }
export async function GET() { return json({ ok: true, demoMode: true, results: DEMO_RESULTS, rows: DEMO_RESULTS, runs: DEMO_RUNS, supervisorTeams: DEMO_SUPERVISOR_TEAMS }); }
export async function POST() { return json({ ok: true, demoMode: true, message: "Demo mode: result action simulated.", results: DEMO_RESULTS, runs: DEMO_RUNS }); }
export async function DELETE() { return json({ ok: true, demoMode: true, message: "Demo mode: delete simulated. No real data was removed." }); }

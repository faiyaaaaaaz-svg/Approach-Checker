import { DEMO_DISPUTES } from "../../../../lib/demoData";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function json(data, init = {}) { return Response.json(data, { status: init.status || 200 }); }
export async function PATCH(request) { const body = await request.json().catch(() => ({})); const dispute = { ...DEMO_DISPUTES[0], status: body.action === "reject" ? "rejected" : "approved", corrected_review_status: body.corrected_review_status || DEMO_DISPUTES[0].corrected_review_status, master_admin_decision_note: body.decision_note || "Demo decision note", reviewed_at: new Date().toISOString() }; return json({ ok: true, demoMode: true, dispute, message: "Demo mode: dispute review simulated." }); }

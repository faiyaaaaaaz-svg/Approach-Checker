import { DEMO_DISPUTES } from "../../../lib/demoData";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function json(data, init = {}) { return Response.json(data, { status: init.status || 200 }); }
export async function GET() { return json({ ok: true, demoMode: true, disputes: DEMO_DISPUTES }); }
export async function POST(request) { const body = await request.json().catch(() => ({})); const dispute = { ...DEMO_DISPUTES[0], id: `demo-dispute-${Date.now()}`, ...body, status: "pending", created_at: new Date().toISOString() }; return json({ ok: true, demoMode: true, dispute, message: "Demo mode: dispute submitted." }); }

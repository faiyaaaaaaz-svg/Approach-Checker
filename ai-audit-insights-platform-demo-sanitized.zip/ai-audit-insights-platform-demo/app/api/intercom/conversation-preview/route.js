import { buildDemoPreview } from "../../../../lib/demoData";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function json(data, init = {}) { return Response.json(data, { status: init.status || 200 }); }
export async function POST(request) {
  const body = await request.json().catch(() => ({}));
  return json(buildDemoPreview(body.conversationId || body.conversation_id || body.resultId));
}

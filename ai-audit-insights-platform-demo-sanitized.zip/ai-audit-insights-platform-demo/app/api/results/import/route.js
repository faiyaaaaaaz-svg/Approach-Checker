import { DEMO_RESULTS } from "../../../../lib/demoData";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function json(data, init = {}) { return Response.json(data, { status: init.status || 200 }); }
export async function POST() { return json({ ok: true, demoMode: true, importedCount: DEMO_RESULTS.length, results: DEMO_RESULTS, message: "Demo mode: import simulated." }); }

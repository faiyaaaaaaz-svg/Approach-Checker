import { findDemoResult } from "../../../../lib/demoData";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
function json(data, init = {}) { return Response.json(data, { status: init.status || 200 }); }
export async function PATCH(request) { const body = await request.json().catch(() => ({})); const result = { ...findDemoResult(body.result_id || body.conversation_id), review_sentiment: body.new_review_status || body.review_sentiment || "Likely Positive Review" }; return json({ ok: true, demoMode: true, result, message: "Demo mode: verdict edit simulated." }); }
export async function POST(request) { return PATCH(request); }
